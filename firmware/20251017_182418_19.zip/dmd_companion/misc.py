'''
Author: ansondeng
Date: 2021-10-13 09:45:05
LastEditTime: 2021-10-13 11:34:48
LastEditors: Please set LastEditors
Description: In User Settings Edit
FilePath: \dmd_companion\misc.py
'''
import os
import sys
import logging
import subprocess
import io
import re
import time
import re


DEFAULT_SSID = 'dmd'
PATH_SAVED_SSID = "/root/saved_ssid"

def get_ssid():
    proc = subprocess.Popen("uci get wireless.default_radio1.ssid", stdout=subprocess.PIPE, shell=True)
    (out, err) = proc.communicate()
    return out[0: len(out)-1]

def is_default_ssid():
	if get_ssid() == DEFAULT_SSID:
		return True
	else:
		return False

def set_ssid(ssid):
	if ssid != None:
		proc = subprocess.Popen("uci set wireless.default_radio1.ssid=" + ssid, stdout=subprocess.PIPE, shell=True)
		(out, err) = proc.communicate()
		os.system('uci commit; sleep 1;wifi')

def set_default_ssid():
	set_ssid(DEFAULT_SSID)


def get_ip():
	proc = subprocess.Popen("uci get network.usbwan.ipaddr", stdout=subprocess.PIPE, shell=True)
	(out, err) = proc.communicate()
	ip = out.split('.')
	logging.debug("ip"+str(ip[0])+str(ip[1])+str(ip[2])+str(ip[3]))
	if len(ip) > 0:
		return (int(ip[3]))*65536*256+(int(ip[2])) *65536 + int(ip[1])*256 + int(ip[0])
	else:
		return 0


def get_saved_ssid():
    try:
        fd = open(PATH_SAVED_SSID)
        saved_ssid = fd.readline()
        fd.close()
        return saved_ssid
    except IOError:
		# no exist
        print("saved ssid no exist")
        return None

def rm_saved_ssid():
    if os.path.exists(PATH_SAVED_SSID):
        os.remove(PATH_SAVED_SSID)
    else:
        print("no saved ssid")

def save_ssid():
	saved_ssid = get_ssid()
	if saved_ssid != DEFAULT_SSID:
		try:
			fd = open("/root/saved_ssid", "w")
			fd.write(saved_ssid)
			fd.close()
		except IOError:
			print("save ssid error")
			fd.close()
	else:
		print("no need to save")

def get_network_sta():
	proc = subprocess.Popen("iwconfig wlan0|grep 'unassociated' -nr", stdout=subprocess.PIPE, shell=True)
	(out,err) = proc.communicate()
	logging.debug('misc| network status'+out)
	return len(out)

def set_ip(ip1,ip2,ip3,ip4):
	os.system(
	"if grep -q '172.' /etc/config/network; then uci set network.usbwan.ipaddr=" + str(ip1) +"."+str(ip2)+"."+str(ip3) +"."+str(ip4)+ ";fi;")
	#os.system("uci set network.usbwan.ipaddr=172." + str(ip1) +"."+str(ip2)+"."+str(ip3))
	os.system("uci commit")
	os.system("/etc/init.d/system reload")
	os.system("sleep 1;wifi")
	logging.debug('companion|set new ip')

def save_dmesg():
	fd = io.open("/root/temp_dmesg", "w", encoding="utf-8")
	p = subprocess.Popen("dmesg", stdout = fd, shell = True)
	p.wait()
	

def get_last_wifi_err_time():
	fd_re = re.compile('\[([ ]*)([0-9]+)\.[0-9]+\] (RTW: WARN  fw read cmd failed...)+')
	fd = io.open("/root/temp_dmesg", "r", encoding="utf-8")
	fd.seek(0)
	list_time = []
	line = "fw read cmd failed..."
	for line in fd:
		match = fd_re.search(line) 
		if match:
			#print(match)
			list_time.append(match.group(2)) 
	
	if len(list_time) > 0:
		logging.warning('wifi rest| len = ' + str(len(list_time)) + 'time = '+ str(int(list_time[len(list_time)-1])))
		return int(list_time[len(list_time)-1])
	return 0


def get_mac_addr():
	proc = subprocess.Popen("ifconfig|grep 'HWaddr' -nr", stdout=subprocess.PIPE, shell=True)
	mac_re = re.compile('([A-Za-z0-9]+):([A-Za-z0-9]+):([A-Za-z0-9]+):([A-Za-z0-9]+):([A-Za-z0-9]+):([A-Za-z0-9]+)')
	(out,err) = proc.communicate()
	mac = mac_re.search(out)
	return mac


