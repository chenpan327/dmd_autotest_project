import Queue
import os
import time
import threading
import select
import traceback
import serial
import struct
import logging
import misc
import crc32
import mavutil
import dmd_uav


ERR = 	0
OK =	1

BL_MSG_ID_COMPANION =	1
BL_MSG_ID_ACK = 		2
BL_MSG_ID_START = 		3
BL_MSG_ID_DATA = 		4
BL_MSG_ID_FINISH = 		5

BL_MSG_HEAD =				0xbe
BL_MSG_SEQ_BYTES =			2
BL_MSG_LEN_BYTES =			2
BL_MSG_CRC_BYTES =			4

PARSER_STATE_IDLE =		1
PARSER_STATE_GOT_HEAD =	2
PARSER_STATE_GOT_ID =	3
PARSER_STATE_GOT_SEQ =	4
PARSER_STATE_GOT_LEN =	5
PARSER_STATE_GOT_DATA =	6

COMPANION_UPDATE =	1
COMPANION_APP =		2

COMPANION_LEN =		1
ACK_LEN =			3
START_LEN =			4
FINISH_LEN =		4
BLOCK_NO_LEN =		2
BLOCK_CRC_LEN =		4
BLOCK_DATA_LEN =	8192
BLOCK_LEN =			BLOCK_NO_LEN + BLOCK_CRC_LEN + BLOCK_DATA_LEN

BL_QUEUE_LEN =			16

SERAIL_READ_TIMEOUT =	1
RESPOND_ACK_TIMEOUT =	1	# 1 second
START_ACK_TIMEOUT =		4

RESPOND_RETRY_TIMES = 	20
UPDATE_RETRY_TIMES =	3
SEND_RETRY_TIMES =		5

UPDATE_STATE_START =			1
UPDATE_STATE_DATA_ALL =			2
UPDATE_STATE_DATA_ONE_BY_ONE =	3
UPDATE_STATE_FINISH =			4
UPDATE_STATE_OVER =				5


MAV_HEARTBEAT_TIMEOUT = 6

class BootloaderMessage(object):
	""" 
		head(1)		0xbe
		id(1)
		seq(2)
		len(2)
		data(n)
		crc(4)
	"""
	send_seq = 0

	def __init__(self, id, seq, len, data):
		self.id =	id
		if seq != None:
			self.seq = seq
		else:
			self.seq = BootloaderMessage.send_seq
			BootloaderMessage.send_seq += 1
		self.len =	len
		self.data =	data

	def get_buf(self):
		""" get msg in bytes """
		buf = bytearray([BL_MSG_HEAD])
		buf.extend(bytearray([self.id]))
		self.seq &= 0xffff
		buf.extend(bytearray(struct.pack('<H', self.seq)))
		buf.extend(bytearray(struct.pack('<H', self.len)))
		buf.extend(self.data)

		crc_msg = crc32.CRC()
		crc_msg.crc32_buffer(buf[1:])
		buf.extend(crc_msg.get_crc32_array())

		return buf


class Ack(object):
	def __init__(self, data):
		self.result =	data[0]
		self.info =		struct.unpack_from('<H', data, 1)[0]


class Bootloader(object):
	""" process bootloader msgs """

	def __init__(self, companion_dir, uart, baud):
		""" open uart, start bootloader msg parser """
		self.firmware_path =		companion_dir + 'dmd_uav.bin'	# '/root/dmduav.bin'
		self.queue_recv =			Queue.Queue(BL_QUEUE_LEN)
		self.port = 				serial.Serial(uart, baud, timeout=SERAIL_READ_TIMEOUT, dsrdtr=False, rtscts=False, xonxoff=False)

		self.thread_parser = 		threading.Thread(target=self._parser,  name="bootloader thread_parser" )
		self.thread_parser.deamon = True


	def _parser(self):
		""" read serial and parser, put to recv queue """
		self.receiving = True

		parser_state = PARSER_STATE_IDLE		
		recv_msg = BootloaderMessage(BL_MSG_ID_ACK, 0, 0, [])
		tmp_buf = bytearray()
		while self.receiving:
			s = self.port.read()
			if len(s) == 0:
				continue
			
			buf = bytearray(s)			
			index = 0
			while index < len(buf):
				c = buf[index]
				#logging.debug('uav| ' + str(c))
				index += 1

				if parser_state == PARSER_STATE_IDLE:
					#logging.debug('uav| PARSER_STATE_IDLE')
					if c == BL_MSG_HEAD:
						parser_state = PARSER_STATE_GOT_HEAD
				elif parser_state == PARSER_STATE_GOT_HEAD:
					#logging.debug('uav| PARSER_STATE_GOT_HEAD')
					if c == BL_MSG_ID_ACK:
						recv_msg = 		BootloaderMessage(BL_MSG_ID_ACK, 0, 0, [])
						parser_state = 	PARSER_STATE_GOT_ID
						tmp_buf = 		bytearray()
					else:
						parser_state = PARSER_STATE_IDLE
				elif parser_state == PARSER_STATE_GOT_ID:
					#logging.debug('uav| PARSER_STATE_GOT_ID')
					tmp_buf.append(c)
					if len(tmp_buf) == BL_MSG_SEQ_BYTES:
						recv_msg.seq =	struct.unpack('<H', tmp_buf)[0]
						parser_state = 	PARSER_STATE_GOT_SEQ
						tmp_buf =		bytearray()
				elif parser_state == PARSER_STATE_GOT_SEQ:
					#logging.debug('uav| PARSER_STATE_GOT_SEQ')
					tmp_buf.append(c)
					if len(tmp_buf) == BL_MSG_LEN_BYTES:
						recv_msg.len =	struct.unpack('<H', tmp_buf)[0]
						if recv_msg.len == ACK_LEN:							
							parser_state = 	PARSER_STATE_GOT_LEN
							tmp_buf =		bytearray()
						else:
							parser_state = PARSER_STATE_IDLE
				elif parser_state == PARSER_STATE_GOT_LEN:
					#logging.debug('uav| PARSER_STATE_GOT_LEN')
					tmp_buf.append(c)
					if len(tmp_buf) == recv_msg.len:
						recv_msg.data = bytearray(tmp_buf)
						parser_state = 	PARSER_STATE_GOT_DATA
						tmp_buf = 		bytearray()
				elif parser_state == PARSER_STATE_GOT_DATA:
					#logging.debug('uav| PARSER_STATE_GOT_DATA')
					tmp_buf.append(c)
					if len(tmp_buf) == BL_MSG_CRC_BYTES:
						msg_buf = recv_msg.get_buf()
						if struct.unpack('<I', tmp_buf)[0] == struct.unpack('<I', msg_buf[-4:])[0]:
							self.queue_recv.put(BootloaderMessage(recv_msg.id, recv_msg.seq, recv_msg.len, recv_msg.data))
							logging.debug('uav|bl parser id:%d seq:%d', recv_msg.id, recv_msg.seq)
						else:
							logging.warning('uav|bl parser err')
						parser_state = PARSER_STATE_IDLE


	def respond(self):
		""" respond flight controller's bootloader """
		logging.info('uav|bl')

		self.thread_parser.start()

		retry = 		0
		has_update = 	False
		if os.path.exists(self.firmware_path):
			logging.info('uav|update')
			has_update = True
		while retry < RESPOND_RETRY_TIMES:
			self._send_companion(has_update)
			retry += 1
			try:
				msg = self.queue_recv.get(True, RESPOND_ACK_TIMEOUT)
				if msg.id == BL_MSG_ID_ACK:
					#logging.debug('ack ' + ','.join('{:02x}'.format(x) for x in msg.data))
					ack = Ack(msg.data)
					#logging.debug('ack ' + str(ack.result) + ' ' + str(ack.info))
					if ack.result == OK and ack.info == BL_MSG_ID_COMPANION:
						logging.debug('uav|ack ok companion')
						break
			except Queue.Empty:
				#logging.debug('timeout')
				continue

		if has_update and retry < RESPOND_RETRY_TIMES:
			try:
				firmware_size = os.path.getsize(self.firmware_path)
				block_num =		(firmware_size - 1) / BLOCK_DATA_LEN + 1
				firmware_file = open(self.firmware_path, 'r')
				logging.debug('firmware_size : ' + str(firmware_size) + ', block_num : ' + str(block_num))

				update_retry = 0
				update_state = UPDATE_STATE_START
				while update_state != UPDATE_STATE_OVER :
					if update_state == UPDATE_STATE_START:
						logging.debug('UPDATE_STATE_START retry ' + str(update_retry))
						if update_retry >= UPDATE_RETRY_TIMES:
							update_state = UPDATE_STATE_OVER
							logging.error('uav|bl state over cause of retry timeout')

							continue
						update_retry += 1

						# init data, send start
						crc32_firmware = crc32.CRC()
						block_flashed = [False] * block_num
						retry = 0
						while retry < SEND_RETRY_TIMES:
							self._send_start(firmware_size)
							retry += 1
							try:
								msg = self.queue_recv.get(True, START_ACK_TIMEOUT)
								if msg.id == BL_MSG_ID_ACK:
									ack = Ack(msg.data)
									if ack.result == OK and ack.info == BL_MSG_ID_START:
										retry = 0
										break;
							except Queue.Empty:
								continue
						if retry < SEND_RETRY_TIMES:
							update_state = UPDATE_STATE_DATA_ALL

					elif update_state == UPDATE_STATE_DATA_ALL:
						# first time, just send without checking ack
						logging.debug('UPDATE_STATE_DATA_ALL')
						block_no = 0
						firmware_file.seek(0)
						while block_no < block_num:							
							logging.debug('			send block start')
							data = firmware_file.read(BLOCK_DATA_LEN)
							self._send_data(block_no, data)
							logging.debug('			send block ' + str(block_no) + ', size ' + str(len(data)))
							crc32_firmware.crc32_buffer(bytearray(data))
							block_no += 1

							if block_no >= block_num:
								time.sleep(RESPOND_ACK_TIMEOUT)
							#else:
								#time.sleep(0.1)

							while not self.queue_recv.empty():
								msg = self.queue_recv.get(False)
								if msg.id == BL_MSG_ID_ACK:
									ack = Ack(msg.data)
									#logging.debug('ack ' + str(ack.result) + ' ' + str(ack.info))
									if ack.result == OK:
										logging.debug('			recv block ack ' + str(ack.info))
										block_flashed[ack.info] = True

						update_state = UPDATE_STATE_DATA_ONE_BY_ONE

					elif update_state == UPDATE_STATE_DATA_ONE_BY_ONE:
						# second time, send next data msg of no acking after receiving last one ack
						logging.debug('UPDATE_STATE_DATA_ONE_BY_ONE')
						block_no = 0
						while block_no < block_num:
							if not block_flashed[block_no]:
								logging.debug('			send block ' + str(block_no))
								firmware_file.seek(block_no * BLOCK_DATA_LEN)
								block_data = firmware_file.read(BLOCK_DATA_LEN)

								retry = 0
								while retry < SEND_RETRY_TIMES:
									self._send_data(block_no, block_data)
									retry += 1
									try:
										logging.debug('			begin recv ' + str(block_no))
										msg = self.queue_recv.get(True, RESPOND_ACK_TIMEOUT)
										if msg.id == BL_MSG_ID_ACK:
											ack = Ack(msg.data)
											if ack.result == OK and ack.info == block_no:
												logging.debug('			recv block ack ' + str(ack.info))
												block_flashed[block_no] = True
												retry = 0
												break
									except Queue.Empty:
										logging.debug('			recv timeout, retry ' + str(retry))
										continue
								if retry >= SEND_RETRY_TIMES:
									update_state = UPDATE_STATE_START
									logging.warning('uav|bl state reset cause of retry timeout in UPDATE_STATE_DATA_ONE_BY_ONE')
									break

							block_no += 1
						update_state = UPDATE_STATE_FINISH

					elif update_state == UPDATE_STATE_FINISH:
						# send finish
						logging.debug('UPDATE_STATE_FINISH')
						retry = 0
						while retry < SEND_RETRY_TIMES:							
							self._send_finish(crc32_firmware.get_crc32())
							retry += 1
							try:
								msg = self.queue_recv.get(True, RESPOND_ACK_TIMEOUT)
								if msg.id == BL_MSG_ID_ACK:
									ack = Ack(msg.data)
									if ack.result == OK and ack.info == BL_MSG_ID_FINISH:
										retry = 0
										break
							except Queue.Empty:
								continue
						if retry < SEND_RETRY_TIMES:
							update_state = UPDATE_STATE_OVER
							logging.info('uav|bl state over ok')
						else:
							update_state = UPDATE_STATE_START
							logging.warning('uav|bl state reset cause of retry timeout in UPDATE_STATE_FINISH')

				firmware_file.close()
				if update_retry < UPDATE_RETRY_TIMES:
					os.remove(self.firmware_path)
					logging.info('uav|bl remove firmware')
				else:
					logging.warning('uav|bl do not remove firmware')

			except:
				logging.exception('uav|')

		self.receiving = False
		self.thread_parser.join()

		self.port.close()


	def _send_companion(self, has_update):
		""" send msg companion """ 		
		if has_update:
			data = bytearray([COMPANION_UPDATE])
		else:
			data = bytearray([COMPANION_APP])
		msg = BootloaderMessage(BL_MSG_ID_COMPANION, None, COMPANION_LEN, data)
		self._send(msg)


	def _send_start(self, data_len):
		""" send msg start_flash """
		data = bytearray(struct.pack('<I', data_len))	
		msg = BootloaderMessage(BL_MSG_ID_START, None, START_LEN, data)
		self._send(msg)


	def _send_data(self, block_no, block_data):
		""" send msg data """
		data = bytearray(struct.pack('<H', block_no))
		crc_block = crc32.CRC()
		data.extend(struct.pack('<I',  crc_block.crc32_buffer(bytearray(block_data))))
		data.extend(bytearray(block_data))
		msg = BootloaderMessage(BL_MSG_ID_DATA, None, BLOCK_NO_LEN + BLOCK_CRC_LEN + len(block_data), data)
		self._send(msg)


	def _send_finish(self, crc):
		""" send msg finish_flash """
		data = bytearray(struct.pack('<I', crc))
		msg = BootloaderMessage(BL_MSG_ID_FINISH, None, FINISH_LEN, data)
		self._send(msg)


	def _send(self, msg):
		array_alpha = msg.get_buf()
		#print 'len is ' + str(len(array_alpha))
		#logging.debug('uav|' + ','.join('{:02x}'.format(x) for x in array_alpha))
		self.port.write(msg.get_buf())
		logging.debug('uav|uart bl send id:%d seq:%d', msg.id, msg.seq)





class UAV(object):
	"""docstring for Uav"""

	def __init__(self, companion_dir, queue_uav_to_companion, queue_companion_to_uav):
		""" respond flight controller's bootloader, and init transfer threads """
		self.uart =						'/dev/ttyS1'
		self.baud =						230400
		self.queue_uav_to_companion = 	queue_uav_to_companion
		self.queue_companion_to_uav = 	queue_companion_to_uav

		bl = Bootloader(companion_dir, self.uart, self.baud)
		bl.respond()

		logging.info('uav|mav')
		self.link = mavutil.mavlink_connection(self.uart, self.baud, input=False)

		self.thread_uart_to_companion = threading.Thread(target=self._transfer_uart_to_companion,  name="uav thread_uart_to_companion" )
		self.thread_uart_to_companion.deamon = True
		self.thread_uart_to_companion.start()

		self.thread_companion_to_uart = threading.Thread(target=self._transfer_companion_to_uart,  name="uav thread_companion_to_uart" )
		self.thread_companion_to_uart.deamon = True
		self.thread_companion_to_uart.start()


	def _transfer_uart_to_companion(self):
		""" parser bytes from uart to mav, send mav msgs to companion """
		while True:
			try:
				(rin, win, xin) = select.select([self.link.fd], [], [], SERAIL_READ_TIMEOUT)

				if len(rin) and rin[0] == self.link.fd:
					s = self.link.recv()
					msgs = self.link.mav.parse_buffer(s)

					if msgs is not None:
						for msg in msgs:
							logging.debug('uav|uart mav recv id:%d seq:%d', msg.get_msgId(), msg.get_seq())
							if msg.get_msgId() != dmd_uav.MAVLINK_MSG_ID_BAD_DATA:
								self.queue_uav_to_companion.put(msg)
			except:
				logging.exception('uav|')



	def _transfer_companion_to_uart(self):
		""" recv mav msgs from companion, pack to bytes and send to uart """
		last_err_wifi_time = 0
		no_gcs_msg_count =0
		while True:
			try:
				try:
					msg = self.queue_companion_to_uav.get(True, MAV_HEARTBEAT_TIMEOUT)
					no_gcs_msg_count = 0
					logging.debug("uav|gcs msg received")
				except Queue.Empty:
					no_gcs_msg_count+=1
					logging.debug("uav|no gcs msg count = %d", no_gcs_msg_count)
					if misc.get_network_sta() == 0:
						self.link.mav.heartbeat_send(2, 21, 0, 0, 0)
						logging.debug('uav|no gcs but can connect to network, append a heartbeat')
						if no_gcs_msg_count >= 15:
							no_gcs_msg_count = 0
							os.system("wifi")
						misc.save_dmesg()
						err_time = misc.get_last_wifi_err_time()
						if err_time > last_err_wifi_time:
							last_err_wifi_time = err_time
							logging.warning('wifi_rest|start reset in uav')
							os.system('rmmod /lib/modules/4.14.81/rtl8812cu.ko;insmod /lib/modules/4.14.81/rtl8812cu.ko rtw_drv_log_level=3;sleep 1;wifi')
							logging.warning('wifi_rest|reset over in uav')
					else:
						self.link.mav.heartbeat_send(2, 21, 0, 0, 1)
						logging.debug('uav|cannot connect to network, append a heartbeat')
					continue
				self.link.write(msg.get_msgbuf())
				#logging.debug('uav|send msg to uav')
			except:
				logging.exception('gcs|')


