'''pymavlink code generator'''
