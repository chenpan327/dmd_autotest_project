from array import array
from encodings import utf_8
from pickle import TRUE
import struct
import Queue
import os
import time
import threading
import select
import traceback
import re
import logging
import subprocess
import serial

import misc
from OmegaExpansion import onionI2C
import onionGpio
import mavutil
import dmd_uav
import crc32
from uav import OK, SEND_RETRY_TIMES, UPDATE_RETRY_TIMES

COMPANION_CHECK_INTERVAL = 5

GPS_BLOCK_DATA_LEN = 128
UNICORE_BLOCK_DATA_LEN = 250
BAT_BLOCK_DATA_LEN = 64
GPS_ACK_QUEUE_LEN = 32
BAT_ACK_QUEUE_LEN = 32
RESPOND_ACK_TIMEOUT = 1 # 1 second

GPS_UPDATE_START                    =   1
GPS_UPDATE_DATA_SEND_ALL            =   2
GPS_UPDATE_DATA_SEND_ONE_BY_ONE     =   3
GPS_UDATE_DATA_CRC                  =   4
GPS_UPDATE_RESET                    =   5

BAT_UPDATE_START                    =   1
BAT_UPDATE_DATA_SEND_ALL            =   2
BAT_UPDATE_DATA_ONE_BY_ONE          =   3
BAT_UPDATE_DATA_CRC                 =   4

UPDATE_COMPANION                    =   1
UPDATE_BATTERY                      =   2
UPDATE_GPS                          =   3
UPDATE_RECEIVER                     =   4
UPDATE_LPPC                         =   5



class Companion(object):
    """docstring for Companion"""

    def __init__(self, companion_dir, queue_uav_to_companion, queue_companion_to_uav, queue_gcs_to_companion, queue_companion_to_gcs,queue_update_type):
        self.companion_dir =			companion_dir					# '/root/'
        self.update_zip_path = 			companion_dir + 'update.zip'	# '/root/update.zip'
        self.gps_path =                 companion_dir + "gps.bin"
        self.battery_path =             companion_dir + "battery.bin"

        self.queue_uav_to_companion = 	queue_uav_to_companion
        self.queue_companion_to_uav = 	queue_companion_to_uav
        self.queue_gcs_to_companion =	queue_gcs_to_companion
        self.queue_companion_to_gcs =	queue_companion_to_gcs
        self.queue_update_type      =   queue_update_type

        self.gps_reply              =   Queue.Queue(GPS_ACK_QUEUE_LEN)
        self.bat_reply              =   Queue.Queue(BAT_ACK_QUEUE_LEN)
        self.bat_verify_reply       =   Queue.Queue(BAT_ACK_QUEUE_LEN)
        self.mav = mavutil.mavlink.MAVLink(file=None, srcSystem=255)

        self.update_type = UPDATE_COMPANION
        self.uav_got_wifi_info = False

        self.set_gps_time = False

        self.gps_type = 0

        self.id = 0
        ssid = "unknow"
        ba = bytearray(ssid, 'ascii')
        while len(ba) < 8:
            ba.append(0)
        self.ssid = ba

        self.quality = 100

        fd_commit_id = open('/root/dmd_companion/GIT_COMMIT_ID', 'r')
        line = fd_commit_id.read(8)
        ba = bytearray(line, 'ascii')
        while len(ba) < 8:
            ba.append(0)
        self.version = ba
        fd_commit_id.close()

        self.update_gps = False
        self.update_bat = False

        self.i2c = onionI2C.OnionI2C()

        self.standby = False
        self.gpio = onionGpio.OnionGpio(41)
        self.gpio.setOutputDirection(1)
        self.gpio.setValue(1)

        self.thread_check = threading.Thread(target=self._check,  name="companion thread_check" )
        self.thread_check.deamon = True
        self.thread_check.start()

        self.thread_uav_to_gcs = threading.Thread(target=self._transfer_uav_to_gcs,  name="companion thread_uav_to_gcs" )
        self.thread_uav_to_gcs.deamon = True
        self.thread_uav_to_gcs.start()

        self.thread_gcs_to_uav = threading.Thread(target=self._transfer_gcs_to_uav,  name="companion thread_gcs_to_uav" )
        self.thread_gcs_to_uav.deamon = True
        self.thread_gcs_to_uav.start()

        self.thread_com_to_uav = threading.Thread(target=self._transfer_com_to_uav,  name="companion thread_com_to_uav" )
        self.thread_com_to_uav.deamon = True
        self.thread_com_to_uav.start()

        self.thread_update_gps = threading.Thread(target=self._update_gps_firmware, name="update gps")
        self.thread_update_gps.daemon = True
        self.thread_update_gps.start()
        
        self.thread_update_battery = threading.Thread(target=self._update_bat_firmware, name = "update bat")
        self.thread_update_battery.daemon = True
        self.thread_update_battery.start()

        logging.info('companion|init, version %s', self.version)

    def _check(self):
        """ check wireless network state """

        # open proc file for wifi state
        fd_wifi =	open('/proc/net/wireless', 'r')
        pre_wifi =	re.compile('[0-9a-zA-Z]*:[\s\.]*[0-9\-]+[\s\.]*([0-9\-]+)[\s\.]*([0-9\-]+)')

        restart_count =	0
        restore_count = 0
        restore_wait = 3
        rewifi_count = 0
        last_err_wifi = 0
        while True:
            #print("check " + str(restart_count))

            match = False
            fd_wifi.seek(0)
            for line in fd_wifi:
                match = pre_wifi.search(line)
                if match:
                    break
            if match:
                self.quality = int(match.group(1))

            out = misc.get_ssid()
            #logging.debug('companion|ssid %s(%d)', out, len(out))
            if len(out)>8:
                out = out[0:8]
            ba = bytearray(out, 'ascii')
            while len(ba) < 8:
                ba.append(0)
            self.ssid = ba

            self.id = misc.get_ip()

            if misc.is_default_ssid():
                restore_wait = 6
            else:
                restore_wait = 18
            if self.quality == 0:
                restart_count += 1
            else:
                restart_count = 0
                restore_count = 0
            if restart_count == 1:   # offline for 5s(1), then check wifi
                restart_count = 0
                rewifi_count+=1

                # ssid restore
                restore_count += 1
                if restore_count == restore_wait:
                    restore_count = 0
                    if misc.is_default_ssid():
                        logging.warning('companion|no connection, switch to saved ssid')
                        saved_ssid = misc.get_saved_ssid()
                        if saved_ssid != None:
                            misc.rm_saved_ssid()
                            misc.set_ssid(saved_ssid)
                    else:
                        logging.warning('companion|no connection, switch to default ssid')
                        misc.save_ssid()
                        misc.set_default_ssid()
                else:
                    logging.warning('companion|no connection, networking restart, count ' + str(restore_count) + ', ssid ' + misc.get_ssid())
                    misc.save_dmesg()
                    
                    err_time = misc.get_last_wifi_err_time()
                    logging.warning('wifi_rest|err_time = ' + str(err_time) + 'last_err_time = ' + str(last_err_wifi))
                    if err_time > last_err_wifi: 
                        last_err_wifi = err_time
                        logging.warning('wifi_rest|start reset')
                        os.system('rmmod /lib/modules/4.14.81/rtl8812cu.ko;insmod /lib/modules/4.14.81/rtl8812cu.ko rtw_drv_log_level=3;sleep 1;wifi')
                        logging.warning('wifi_rest|reset over')
                    elif rewifi_count == 6:
                        rewifi_count = 0
                        os.system('wifi')
            #logging.debug('companion|check: ' + str(restart_count) + ' ' + str(self.ssid) + ' ' + str(self.quality))
            time.sleep(COMPANION_CHECK_INTERVAL)



    def _transfer_uav_to_gcs(self):
        while True:
            try:
                msg = self.queue_uav_to_companion.get()
                self.mav.srcSystem = msg.get_srcSystem()
                # replace
                if msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_PACKED_STATE:
                    msg.wifi_up = 	self.quality
                    self.mav.seq = msg.get_seq()
                    msg.pack(self.mav)
                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_EXTEND_STATE:
                    msg.companion_version = self.version
                    self.mav.seq = msg.get_seq()
                    msg.pack(self.mav)
                    gps_version = msg.gps_version
                    for i in range(0,8):
                        gps_version[i] = chr(msg.gps_version[i])
                    version = ''.join(gps_version).strip('\0') 
                    logging.debug("gps_version is"+version)

                    if str(version).find("UM") != -1:
                        self.gps_type = 0
                    else:
                        self.gps_type = 1
                    logging.debug("gps_type is "+ str(self.gps_type))
                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_UPDATE_GPS_COMPANION_PACKET_ACK:
                    self.gps_reply.put(msg)
                    #logging.debug('restore gps update ack')
                    continue
                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_UPDATE_BATTERY_COMPANION_PACKET_ACK:
                    self.bat_reply.put(msg)
                    logging.debug("bat|restore bat packet ack")
                    continue
                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_UPDATE_BATTERY_COMPANION_VERIFY_ACK:
                    self.bat_verify_reply.put(msg)
                    continue
                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_EULER_NETWORK:
                    # change ssid ange ip by uav usb not gcs

                    # reply to uav
                    ack = dmd_uav.MAVLink_command_ack_message(dmd_uav.MAVLINK_MSG_ID_EULER_NETWORK, 0)
                    ack.pack(self.mav)
                    self.queue_companion_to_uav.put(ack)

                    # change ssid
                    ssid = msg.ssid
                    for i in range(0, 8):
                        ssid[i] = chr(msg.ssid[i])
                    new_ssid = ''.join(ssid).strip('\0')
                    logging.info("rec set ssid to:"+new_ssid)

                    cur_ssid = misc.get_ssid()
                    logging.info("cur ssid:" + cur_ssid)
                    if(cur_ssid != new_ssid):
                        misc.set_ssid(new_ssid)

                    # change ip
                    new_ip = msg.id
                    if(new_ip != 0):
                        new_ip4 = (int(new_ip)&(0xFF000000))>>24
                        new_ip3 = (int(new_ip)&(0x00FF0000))>>16
                        new_ip2 = (int(new_ip)&(0x0000FF00))>>8
                        new_ip1 = (int(new_ip)&(0x000000FF))
                        cur_ip = misc.get_ip()
                        if cur_ip != new_ip :
                           misc.set_ip(new_ip1,new_ip2,new_ip3,new_ip4)
                    self.uav_got_wifi_info = False

                    continue
                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_COMMAND_ACK:
                    if msg.command == dmd_uav.MAVLINK_MSG_ID_HEARTBEAT_DMD:
                        logging.debug("uav_got_wifi_info = True")
                        self.uav_got_wifi_info = True
                        continue
                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_SET_GPS_TIME:
                    if self.set_gps_time == False and msg.time_valid == 1:
                        #set gps time
                        time_local = time.time()
                        if float(time_local) > float(msg.time/1000):
                            logging.debug("time err do not set")
                            continue
                        timearray = time.localtime(msg.time/1000)
                        timestring = time.strftime("%Y-%m-%d %H:%M:%S", timearray)
                        os.system("date -s '" + timestring+"'")
                        self.set_gps_time = True
                        logging.debug("set gps time ok")
                    continue    
                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_COMMAND_LONG:
                    if msg.command == dmd_uav.MAV_CMD_WIFI_MAC_ADDR and msg.param1 == 0:
                        mac = misc.get_mac_addr()
                        msg_cmd = dmd_uav.MAVLink_command_long_message(0, 0, dmd_uav.MAV_CMD_WIFI_MAC_ADDR,0, 0, int(mac.group(1),16),int(mac.group(2),16),int(mac.group(3),16), int(mac.group(4), 16),int(mac.group(5), 16),int(mac.group(6), 16))
                        msg_cmd.pack(self.mav)
                        self.queue_companion_to_uav.put(msg_cmd)
                        continue
                    elif msg.command == dmd_uav.MAV_CMD_WIFI_MAC_ADDR and msg.param1 == 1:
                        ip = misc.get_ip()
                        ip4 = (int(ip)&(0xFF000000))>>24
                        ip3 = (int(ip)&(0x00FF0000))>>16
                        ip2 = (int(ip)&(0x0000FF00))>>8
                        ip1 = (int(ip)&(0x000000FF))
                        msg_cmd = dmd_uav.MAVLink_command_long_message(0, 0, dmd_uav.MAV_CMD_WIFI_MAC_ADDR,0, 1, int(ip1),int(ip2),int(ip3), int(ip4),0,0)
                        msg_cmd.pack(self.mav)
                        self.queue_companion_to_uav.put(msg_cmd)
                        continue
                self.queue_companion_to_gcs.put(msg)
            except:
                logging.exception('companion|')


    def _transfer_gcs_to_uav(self):
        uart= '/dev/ttyS1'
        port = serial.Serial(uart,230400,timeout=0,rtscts=False,xonxoff = False, dsrdtr=False)
        while True:
            try:
                msg = self.queue_gcs_to_companion.get()
                self.mav.srcSystem = msg.get_srcSystem()
                if msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_HEARTBEAT_DMD:
                    msg.ssid =	self.ssid
                    #logging.debug('extend %d, id %d, ssid %s', msg.extend, msg.id, msg.ssid)
                    self.mav.seq = msg.get_seq()
                    msg.pack(self.mav)
                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_STRIP_LIGHT: 
                    send_bytes = [0x55, msg.m, msg.c0_r, msg.c0_g, msg.c0_b, msg.c1_r, msg.c1_g, msg.c1_b, msg.c2_r, msg.c2_g, msg.c2_b, msg.s, msg.d, msg.l, msg.n, 0, 0xf0]
                    for i in range(1, 15):
                        send_bytes[15] ^= send_bytes[i]
                    logging.info('companion|strip light mode %d', msg.m)
                    self.i2c.write(0x06, send_bytes)
                    msg = None # del msg, not send to mcu
                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_COMMAND_LONG:
                    if msg.command == dmd_uav.MAV_CMD_UPDATE_COMPANION and msg.param1 == 0:	# cmd of updating firmware
                        # unzip, delete
                        self.update_type = UPDATE_COMPANION
                        self.queue_update_type.put(self.update_type)
                        logging.info('kill ftpd')
                        os.system("kill -9 $(ps | grep ftpd | grep -v grep | awk '{print $1}')")
                        logging.info('companion|update companion, unzip delete begin , param = %d' ,msg.param1)
                        param1 = 0
                        firmware_path = self.companion_dir + 'dmd_uav.bin'
                        if os.path.exists(self.update_zip_path) : #and not os.path.exists(firmware_path):
                            logging.info('unzip -o -d ' + self.companion_dir + ' ' + self.update_zip_path)
                            os.system('unzip -o -d ' + self.companion_dir + ' ' + self.update_zip_path)
                            if os.path.exists(firmware_path):
                                os.remove(self.update_zip_path)
                            else:
                                logging.error('companion|no fc bin')
                                param1 = 255   
                        else:
                            param1 = 255
                            logging.debug("companion|no zip")
                        msg.param1 = param1
                        self.mav.seq = msg.get_seq()
                        msg.pack(self.mav)
                        logging.info('companion|update companion, unzip delete end')
                    elif msg.command == dmd_uav.MAV_CMD_UPDATE_COMPANION and msg.param1 == 1:
                        self.update_type = UPDATE_BATTERY
                        self.queue_update_type.put(self.update_type)
                        logging.info('ready to update battery, start update battery thread')
                        param1 = 1
                        if os.path.exists(self.battery_path):
                            self.update_bat = True
                            logging.info('battery bin transmit complete')
                        else:
                            logging.error('no battery bin')
                            param1 = 255
                        msg.param1 = param1
                        self.mav.seq = msg.get_seq()
                        msg.pack(self.mav)
                    elif msg.command == dmd_uav.MAV_CMD_UPDATE_COMPANION  and msg.param1 == 2:
                        logging.info('ready to update gps, start update gps thread')
                        self.update_type = UPDATE_GPS
                        self.queue_update_type.put(self.update_type)
                        param1 = 2
                        if os.path.exists(self.gps_path):
                            self.update_gps = True
                            logging.info('gps|gps bin transmit complete')
                        else:
                            logging.error('gps|no gps bin')    
                            param1 = 255
                        msg.param1 = param1
                        self.mav.seq = msg.get_seq()
                        msg.pack(self.mav)
                        #else:
                        #    if not os.path.exists(self.update_zip_path):
                        #        logging.error('companion|no zip file ' + self.update_zip_path)
                        #    else:
                        #        logging.error('companion|' + firmware_path + ' already exists')
                        #    param1 = 1
                       

                        # param1: 0--update ok, 1--wrong
                        # send to fc. fc will ack cmd and reset according to param1
                    elif msg.command == dmd_uav.MAV_CMD_STANDBY:
                            # make ack
                        msg_ack = dmd_uav.MAVLink_command_ack_message(dmd_uav.MAV_CMD_STANDBY, dmd_uav.MAV_RESULT_ACCEPTED)
                        msg_ack.pack(self.mav)
                        self.queue_companion_to_gcs.put(msg_ack)
                        if msg.param1 == 1:
                            msg = None
                            # standby
                            if not self.standby :
                                self.standby = True
                                self.gpio.setValue(0)
                                if port.is_open == True:
                                    logging.debug('companion|close uart')
                                    port.close()
                                logging.info('companion|standby')
                        elif msg.param1 == 0:
                            msg = None
                            # resume and restart self 
                            if self.standby :
                                self.standby = False
                                self.gpio.setValue(1)
                                if port.is_open == False:
                                    logging.debug('companion|reopen uart')
                                    port.open()
                                logging.info('companion|resume and restart')
                                # end this thread, then main thread will restart the entire app
                                break
                        elif msg.param1 == 2:
                            msg.param1 = 2
                            self.mav.seq = msg.get_seq()
                            msg.pack(self.mav)
                    elif msg.command == dmd_uav.MAV_CMD_SWITCH_DHCP:
                        msg_ack = dmd_uav.MAVLink_command_ack_message(dmd_uav.MAV_CMD_SWITCH_DHCP, dmd_uav.MAV_RESULT_ACCEPTED)
                        msg_ack.pack(self.mav)
                        self.queue_companion_to_gcs.put(msg_ack)
                        if msg.param1 == 1:
                            os.system("if grep -q '172.' /etc/config/network; then cp /etc/config/network /etc/config/network_static;fi;")
                            os.system("if grep -q '172.' /etc/config/network;then cp /etc/config/network_dhcp /etc/config/network;fi;")
                        elif msg.param1 == 0:
                            os.system("cp /etc/config/network_static /etc/config/network")
                        os.system("sleep 1;wifi")
                    elif msg.command == dmd_uav.MAV_CMD_DELETE_MAC:
                        msg_ack = dmd_uav.MAVLink_command_ack_message(dmd_uav.MAV_CMD_DELETE_MAC, dmd_uav.MAV_RESULT_ACCEPTED)
                        msg_ack.pack(self.mav)
                        self.queue_companion_to_gcs.put(msg_ack)
                        os.system("if grep -q 'bssid' /etc/config/wireless; then sed -i '/bssid/d' /etc/config/wireless;fi;")

                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_EULER_NETWORK:
                    ack = dmd_uav.MAVLink_command_ack_message(dmd_uav.MAVLINK_MSG_ID_EULER_NETWORK, 0)
                    ack.pack(self.mav)
                    self.queue_companion_to_gcs.put(ack)
                    time.sleep(5)

                    # change ssid
                    ssid = msg.ssid
                    for i in range(0, 8):
                        ssid[i] = chr(msg.ssid[i])
                    new_ssid = ''.join(ssid).strip('\0')
                    logging.info("rec set ssid to:"+new_ssid)

                    cur_ssid = misc.get_ssid()
                    logging.info("cur ssid:" + cur_ssid)
                    if(cur_ssid != new_ssid):
                        logging.info('companion|set ssid')
                        misc.set_ssid(new_ssid)

                    # change ip
                    new_ip = msg.id
                    logging.debug("new ip:"+str(new_ip))
                    if(new_ip != 0):
                        new_ip4 = (int(new_ip)&(0xFF000000))>>24
                        new_ip3 = (int(new_ip)&(0x00FF0000))>>16
                        new_ip2 = (int(new_ip)&(0x0000FF00))>>8
                        new_ip1 = (int(new_ip)&(0x000000FF))
                        cur_ip = misc.get_ip()
                        logging.debug("cur_ip:"+str(cur_ip))
                        if cur_ip != new_ip :
                            misc.set_ip(new_ip1,new_ip2,new_ip3,new_ip4)
                            logging.info("uci set network.usbwan.ipaddr=" + str(new_ip1) + "." + str(new_ip2)+"." + str(new_ip3)+"." + str(new_ip4))
                            # for dhcp, no set ip
                            # os.system(
                            #     "if grep -q '172.' /etc/config/network; then uci set network.usbwan.ipaddr=172.16." + str(
                            #         new_ip1) + "." + str(new_ip2) + ";fi;")
                            # os.system("uci commit")
                            # os.system("/etc/init.d/system reload")
                            # os.system("wifi")

                    self.uav_got_wifi_info = False
                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_SUBMOD_FIRMWARE_INFO:
                    if msg.get_fieldnames()[0] == 0:
                        self.update_type = UPDATE_RECEIVER
                        logging.info('ready to update receiver, start update receiver thread')
                    elif msg.get_fieldnames()[0] == 1:
                        self.update_type = UPDATE_LPPC
                        logging.info('ready to update lppc, start update lppc thread')
                    self.mav.seq = msg.get_seq()
                    msg.pack(self.mav)
                elif msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_SUBMOD_UPDATE_PACKAGE:
                    self.mav.seq = msg.get_seq()
                    msg.pack(self.mav)
                if msg is not None:
                    self.queue_companion_to_uav.put(msg)
            except:
                logging.exception('companion|')

    def _transfer_com_to_uav(self):
        while True:
            try:
                time.sleep(5)
                logging.debug("_transfer_com_to_uav")
                if not self.uav_got_wifi_info:
                    logging.debug("uav_got_wifi_info")
                    logging.debug("ssid len:"+str(len(misc.get_ssid())))
                    ssid = misc.get_ssid()
                    ssid_len = len(ssid)
                    ssid_array = [0]*8
                    for i in range(ssid_len):
                        ssid_array[i] = ord(ssid[i])
                    msg = dmd_uav.MAVLink_heartbeat_dmd_message(21,0,ssid_array,0)
                    # logging.debug('extend %d, id %d, ssid %s', msg.extend, msg.id, msg.ssid)
                    msg.pack(self.mav)
                    self.queue_companion_to_uav.put(msg)
            except:
                logging.exception('companion|')

    def _checksum_f9p(self, size):
        cha = 0
        chb = 0
        index = 0
        if size%4 == 0 :
            size /= 4
        else:
            size = size/4 +1
        file_gps = open(self.gps_path,'rb')
        arr = array('I')
        arr.fromfile(file_gps,size)
        while index < size :
            cha += arr[index]
            chb += cha
            index += 1
        cha = cha & 0xffffffff
        chb = chb & 0xffffffff
        return [cha, chb]



    def _update_gps_firmware(self):
        state = GPS_UPDATE_START
        while True:
            if self.update_gps != True:
                state = GPS_UPDATE_START
                #logging.debug('gps|update thread sleep' + str(self.update_gps))
                time.sleep(1)
                continue
            if self.gps_type == 1:
                if state == GPS_UPDATE_START:
                    if os.path.exists(self.gps_path):
                        firmware_size = os.path.getsize(self.gps_path)
                        block_num = (firmware_size - 1)/GPS_BLOCK_DATA_LEN + 1
                        firmware_file = open(self.gps_path, 'r')
                        logging.debug('gps|gps_firmware_size : ' + str(firmware_size) + ', block_num: ' + str(block_num))
                        buf = 250*[0]
                        msg = dmd_uav.MAVLink_update_gps_companion_packet_message(block_num,0,buf)
                        msg.pack(self.mav)
                        self.queue_companion_to_uav.put(msg)
                        block_flashed = [False] * block_num
                        try:
                            ack = self.gps_reply.get(True, 50* RESPOND_ACK_TIMEOUT)
                            logging.debug('gps|ack result = %d , ack.seq = %d', ack.result, ack.seq)
                            if(ack.result == 0 and ack.seq == block_num):
                                logging.debug('gps|start update gps')
                                time.sleep(1)
                                state = GPS_UPDATE_DATA_SEND_ALL
                                continue
                        except Queue.Empty:
                            state = GPS_UPDATE_START
                            self.update_gps =False
                            os.system('rm -f ' + self.gps_path)
                            logging.debug('gps|can not update gps, start failed')
                            continue 
                elif state == GPS_UPDATE_DATA_SEND_ALL:
                    #send all
                    logging.debug('gps|send all data without ack')
                    block_no = 0
                    firmware_file.seek(0)
                    while block_no < block_num:
                        logging.debug('gps|send block start')
                        data = firmware_file.read(GPS_BLOCK_DATA_LEN)
                        msg = dmd_uav.MAVLink_update_gps_companion_packet_message(block_no, len(data), bytearray(data).ljust(250,'0'))
                        logging.debug('gps|send block' + str(block_no)+ ',size ' + str(len(data)))
                        msg.pack(self.mav)
                        self.queue_companion_to_uav.put(msg)
                        block_no += 1
                        if block_no >= block_num:
                            time.sleep(1)
                        else:
                            time.sleep(0.01)
                        while not self.gps_reply.empty():
                            ack = self.gps_reply.get(False)
                            if(ack.result == 0 and ack.seq < block_num):
                                logging.debug('gps|recv block ack' + str(ack.seq))
                                block_flashed[ack.seq] = True
                    
                    state = GPS_UPDATE_DATA_SEND_ONE_BY_ONE
                elif state == GPS_UPDATE_DATA_SEND_ONE_BY_ONE:
                    block_no = 0
                    firmware_file.seek(0)
                    while block_no < block_num:
                        if not block_flashed[block_no]:
                            firmware_file.seek(block_no * GPS_BLOCK_DATA_LEN)
                            data = firmware_file.read(GPS_BLOCK_DATA_LEN)
                        #send data
                            retry = 0
                            while retry < SEND_RETRY_TIMES:
                                msg = dmd_uav.MAVLink_update_gps_companion_packet_message(block_no,len(data),bytearray(data).ljust(250,'0'))
                                msg.pack(self.mav)
                                self.queue_companion_to_uav.put(msg)
                                logging.debug('gps|send block' + str(block_no) + ', size' + str(len(data)))
                                retry += 1
                                try:
                                    ack = self.gps_reply.get(True, 5*RESPOND_ACK_TIMEOUT)
                                    if(ack.result == 0 and ack.seq == block_no):
                                        block_flashed[block_no] = True
                                        retry = 0
                                        logging.debug('gps|recv gps block ack ' + str(ack.seq))
                                        break
                                except Queue.Empty:
                                    logging.debug('gps|recv gps ack timeout, retry' + str(retry))
                                    continue
                            if retry >= SEND_RETRY_TIMES:
                                state = GPS_UPDATE_START
                                self.update_gps = False
                                os.system('rm -f ' + self.gps_path)
                                logging.warning('gps|gps update failed cause of timeout')
                                break
                        block_no += 1
                    state = GPS_UDATE_DATA_CRC
                elif state == GPS_UDATE_DATA_CRC:
                    list = self._checksum_f9p(firmware_size)
                    arr = array('I')
                    arr.fromlist(list)
                    arr.append(firmware_size)
                    #byte = arr.tostring()
                    #logging.debug('gps|byte= ', byte)
                    retry = 0
                    #self.gps_reply.clear()
                    while retry < SEND_RETRY_TIMES:
                        msg = dmd_uav.MAVLink_update_gps_companion_packet_message(block_num+1,12,bytearray(struct.pack('<3I',arr[0],arr[1],arr[2])).ljust(250,'0'))
                        msg.pack(self.mav)
                        self.queue_companion_to_uav.put(msg)
                        logging.debug('gps|gps send crc ' + str(arr))
                        retry += 1
                        try:
                            ack = self.gps_reply.get(True, 10*RESPOND_ACK_TIMEOUT)
                            if(ack.result ==0 and ack.seq == block_num+1):
                                break
                        except Queue.Empty:
                            logging.debug('gps|gps crc failed')
                            continue
                    if retry >= SEND_RETRY_TIMES:
                        state = GPS_UPDATE_START
                        self.update_gps = False
                        logging.warning('gps|gps crc timeout')
                        continue
                    state = GPS_UPDATE_RESET
                elif state == GPS_UPDATE_RESET:
                    #reset FLIGHT CONTROL
                    self.update_gps = False
                    state = GPS_UPDATE_START
                    time.sleep(5)
                    self.gpio.setValue(0)
                    time.sleep(2)
                    self.gpio.setValue(1)
                    os.system('rm -f ' + self.gps_path)
                    logging.info('gps|delete the gps bin')
            elif self.gps_type == 0:
                if state == GPS_UPDATE_START:
                    if os.path.exists(self.gps_path):
                        firmware_size = os.path.getsize(self.gps_path)
                        block_num = (firmware_size - 1)/UNICORE_BLOCK_DATA_LEN + 1
                        firmware_file = open(self.gps_path, 'r')
                        logging.debug('gps|gps_firmware_size : ' + str(firmware_size) + ', block_num: ' + str(block_num))
                        buf = 250*[0]
                        msg = dmd_uav.MAVLink_update_gps_companion_packet_message(block_num,0,buf)
                        msg.pack(self.mav)
                        self.queue_companion_to_uav.put(msg)
                        try:
                            ack = self.gps_reply.get(True, 50* RESPOND_ACK_TIMEOUT)
                            logging.debug('gps|ack result = %d , ack.seq = %d', ack.result, ack.seq)
                            if(ack.result == 0 and ack.seq == block_num):
                                logging.debug('gps|start update gps')
                                time.sleep(1)
                                state = GPS_UPDATE_DATA_SEND_ONE_BY_ONE
                                continue
                        except Queue.Empty:
                            state = GPS_UPDATE_START
                            self.update_gps =False
                            os.system('rm -f ' + self.gps_path)
                            logging.debug('gps|can not update gps, start failed')
                            continue 
                elif state  == GPS_UPDATE_DATA_SEND_ONE_BY_ONE:
                    block_no = 0
                    firmware_file.seek(0)
                    while block_no < block_num:
                        firmware_file.seek(block_no * UNICORE_BLOCK_DATA_LEN)
                        data = firmware_file.read(UNICORE_BLOCK_DATA_LEN)
                        #send data
                        retry = 0
                        # while retry < 2*SEND_RETRY_TIMES:
                        msg = dmd_uav.MAVLink_update_gps_companion_packet_message(block_no,len(data),bytearray(data).ljust(UNICORE_BLOCK_DATA_LEN,'0'))
                        msg.pack(self.mav)
                        self.queue_companion_to_uav.put(msg)
                        logging.debug('gps|send block' + str(block_no) + ', size' + str(len(data)))
                        retry += 1
                        try:
                            ack = self.gps_reply.get(True, 0.015)
                            if(ack.result == 1):
                                block_no = ack.seq
                                logging.debug('gps|block ack block num fail ' + str(ack.seq))
                                time.sleep(1)
                                continue                                   
                        except Queue.Empty:
                            logging.debug('gps|no ack send next')                                
                        # if retry >= 2*SEND_RETRY_TIMES:
                        #     state = GPS_UPDATE_START
                        #     self.update_gps = False
                        #     os.system('rm -f ' + self.gps_path)
                        #     logging.warning('gps|gps update failed cause of timeout')
                        #     break
                        block_no += 1
                    state = GPS_UPDATE_RESET
                elif state == GPS_UPDATE_RESET:
                    self.update_gps = False
                    state = GPS_UPDATE_START
                    time.sleep(30)
                    self.gpio.setValue(0)
                    time.sleep(2)
                    self.gpio.setValue(1)
                    os.system('rm -f ' + self.gps_path)
                    os.system('rm -f ' + self.gps_path)
                    logging.info('gps|delete the gps bin')
                    

    

    def _update_bat_firmware(self):
        state = BAT_UPDATE_START
        while True:
            if self.update_bat != True:
                state = BAT_UPDATE_START
                time.sleep(1)
                continue
            if state == BAT_UPDATE_START:
                if os.path.exists(self.battery_path):
                    firmware_size = os.path.getsize(self.battery_path)
                    block_num = (firmware_size - 1)/BAT_BLOCK_DATA_LEN + 1
                    firmware_file = open(self.battery_path,'r')
                    logging.debug('bat|bat_firmware_size : ' + str(firmware_size))
                    buf = 250*[0]
                    msg = dmd_uav.MAVLink_update_battery_companion_packet_message(0, 0, buf)
                    msg.pack(self.mav)
                    self.queue_companion_to_uav.put(msg)
                    block_flashed = [False] * block_num
                    try:
                        ack = self.bat_reply.get(True, RESPOND_ACK_TIMEOUT * 5)
                        logging.debug('bat|ack result = %d, ack.seq = %d', ack.result, ack.seq)
                        if(ack.result == 0 and ack.seq == 0):
                            logging.debug('bat|bat update start')
                            time.sleep(0.5)
                            state = BAT_UPDATE_DATA_ONE_BY_ONE
                            continue
                    except Queue.Empty:
                        state = BAT_UPDATE_START
                        self.update_bat = False
                        os.system('rm -f ' + self.battery_path)
                        logging.debug('bat|cannot update bat, start failed')
                        continue
            # elif state == BAT_UPDATE_DATA_SEND_ALL:
            #     logging.debug('bat|send all data without ack')
            #     block_no = 0
            #     firmware_file.seek(0)
            #     while block_no < block_num:
            #         logging.debug('bat|send block start')
            #         data = firmware_file.read(BAT_BLOCK_DATA_LEN)
            #         msg = dmd_uav.MAVLink_update_battery_companion_packet_message(block_no, len(data), bytearray(data).ljust(250, '0'))
            #         logging.debug('bat|send block' + str(block_no))
            #         msg.pack(self.mav)
            #         self.queue_companion_to_uav.put(msg)
            #         block_no += 1
            #         if block_no >=  block_num:
            #             time.sleep(0.5)
            #         else :
            #             time.sleep(0.01)
            #         while not self.bat_reply.empty():
            #             ack = self.bat_reply.get(False)
            #             if(ack.result == 0 and ack.seq < block_num):
            #                 logging.debug('bat|recv block ack' + str(ack.seq))
            #                 block_flashed[ack.seq] = True
            #     state = BAT_UPDATE_DATA_ONE_BY_ONE
            elif state == BAT_UPDATE_DATA_ONE_BY_ONE:
                block_no = 0
                firmware_file.seek(0)
                retry = 0
                while block_no < block_num:
                    if not block_flashed[block_no]:
                        firmware_file.seek(block_no * BAT_BLOCK_DATA_LEN)
                        data = firmware_file.read(BAT_BLOCK_DATA_LEN)
                        while retry < SEND_RETRY_TIMES:
                            msg = dmd_uav.MAVLink_update_battery_companion_packet_message(block_no+1, len(data), bytearray(data).ljust(250, '0'))
                            msg.pack(self.mav)
                            self.queue_companion_to_uav.put(msg)
                            logging.debug('bat|send block ' + str(block_no) + ', size ' +str(len(data)))
                            retry += 1
                            try:
                                ack = self.bat_reply.get(True, 5*RESPOND_ACK_TIMEOUT)
                                logging.debug('bat|recv gps block ack '+ str(ack.seq))
                                if (ack.result == 0 and ack.seq == block_no+1):
                                    block_flashed[block_no] = True
                                    retry = 0
                                    break
                            except Queue.Empty:
                                logging.debug('bat|recv gps ack timeout , retry' + str(retry))
                                continue
                        if retry >= SEND_RETRY_TIMES:
                            state = GPS_UPDATE_START
                            self.update_bat = False
                            os.system('rm -f ' + self.battery_path)
                            logging.warning('bat| bat update failed cause of timeout')
                            break
                    block_no += 1
                if retry < SEND_RETRY_TIMES:
                    state = BAT_UPDATE_DATA_CRC
            elif state == BAT_UPDATE_DATA_CRC:
                #crc
                firmware_file.seek(0)
                buf = firmware_file.read(firmware_size)
                crc32_firmware = crc32.CRC()
                crc = crc32_firmware.crc32_buffer(bytearray(buf))
                retry = 0
                while retry < SEND_RETRY_TIMES:
                    msg = dmd_uav.MAVLink_update_battery_companion_verify_message(crc)
                    msg.pack(self.mav)
                    self.queue_companion_to_uav.put(msg)
                    logging.debug('bat|bat send crc' + str(crc))
                    retry += 1
                    try:
                        ack = self.bat_verify_reply.get(True, 5*RESPOND_ACK_TIMEOUT)
                        if ack.result == 0:
                            break
                    except Queue.Empty:
                        logging.debug('bat|bat crc failed')
                        continue
                if retry >= SEND_RETRY_TIMES:
                    state = BAT_UPDATE_START
                    self.update_bat = False
                    os.system('rm -f ' + self.battery_path)
                    logging.warning('bat|bat crc failed')
                    continue
                