import Queue
import time
import threading
import select
import traceback
import logging

import mavutil
import dmd_uav
import os
import companion

UDP_READ_TIMEOUT = 		1
MAV_HEARTBEAT_TIMEOUT = 5


class GCS(object):
	"""docstring for GCS"""

	def __init__(self, queue_gcs_to_companion, queue_companion_to_gcs, queue_update_type):
		self.udp = 						'172.16.200.1:14550'
		self.queue_gcs_to_companion =	queue_gcs_to_companion
		self.queue_companion_to_gcs =	queue_companion_to_gcs
		self.queue_update_type		= 	queue_update_type

		self.firmware_path			=	'/root/dmd_uav.bin'

		self.link = mavutil.mavlink_connection(self.udp, input=False)

		self.thread_udp_to_companion = threading.Thread(target=self._transfer_udp_to_companion,  name="gcs thread_udp_to_companion" )
		self.thread_udp_to_companion.deamon = True
		self.thread_udp_to_companion.start()

		self.thread_companion_to_udp = threading.Thread(target=self._transfer_companion_to_udp,  name="gcs thread_companion_to_udp" )
		self.thread_companion_to_udp.deamon = True
		self.thread_companion_to_udp.start()

		logging.info('gcs|init')


	def _transfer_udp_to_companion(self):
		while True:
			try:
				#logging.debug('_transfer_udp_to_companion')
				(rin, win, xin) = select.select([self.link.fd], [], [], UDP_READ_TIMEOUT)

				if len(rin) and rin[0] == self.link.fd:
					s = self.link.recv()
					msgs = self.link.mav.parse_buffer(s)

					if msgs is not None:
						for msg in msgs:
							logging.debug('gcs|udp mav recv id:%d seq:%d', msg.get_msgId(), msg.get_seq())
							if msg.get_msgId() != dmd_uav.MAVLINK_MSG_ID_BAD_DATA:
								self.queue_gcs_to_companion.put(msg)
			except:
				logging.exception('gcs|')



	def _transfer_companion_to_udp(self):
		while True:
			try:
				#logging.debug('_transfer_companion_to_udp')
				try:
					msg = self.queue_companion_to_gcs.get(True, MAV_HEARTBEAT_TIMEOUT)
					#logging.debug('gcs|~~~~~udp mav send id:%d seq:%d', msg.get_msgId(), msg.get_seq())
				except Queue.Empty:
					# send hb to keep gcs alive
					#logging.debug('gcs|ready to send')
					self.link.mav.heartbeat_send(2, 21, 0, 0, 0)	# type autopilot, base_mode, custom_mode, system_status
					logging.debug('gcs|no msg to send to gcs, append a heartbeat')
					continue				
				self.link.write(msg.get_msgbuf())

				if msg.get_msgId() == dmd_uav.MAVLINK_MSG_ID_COMMAND_ACK and msg.command == dmd_uav.MAV_CMD_UPDATE_COMPANION and msg.result == dmd_uav.MAV_RESULT_ACCEPTED:
					# fc accept update cmd and reset , ack has been sent to pc.
					# make sure pc recv ack, send once more after 1s
					try:
						self.update_type = self.queue_update_type.get(True, 1)
					except Queue.Empty:
						continue 
					if self.update_type == companion.UPDATE_COMPANION:
						#time.sleep(1)
						self.link.write(msg.get_msgbuf())
						# end this thread, then main thread will restart the entire app
						logging.debug('gcs|fc accept update cmd and reset, end thread thread_companion_to_udp !!!')
						break;


			except:
				logging.exception('gcs|')

