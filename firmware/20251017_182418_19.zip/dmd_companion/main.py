'''
Author: ansondeng
Date: 2021-10-13 09:45:05
LastEditTime: 2021-10-13 11:26:11
LastEditors: ansondeng
Description: In User Settings Edit
FilePath: \dmd_companion\main.py
'''
import os
import Queue
import time
import logging
import shutil
import sys
import signal
import subprocess

import onionGpio

import uav
import gcs
import companion
import misc
from logging.handlers import RotatingFileHandler


def quit(signum, frame):
    print 'You choose to stop me.'
    sys.exit()


def kill_ftpd():
	pid = ""
	try:
		pid = subprocess.check_output(['pgrep', '-f', 'ftpd']).strip()
	except subprocess.CalledProcessError:
		pid = None

	if pid:
		subprocess.call(['kill', '-9', pid])
		print("kill ftpd success")

def run_ftpd():
	p = subprocess.Popen(['chmod', '+x', '/root/dmd_companion/ftpd'])
	p.wait()
	with open('/dev/null', 'w') as devnull:
		subprocess.Popen(['/root/dmd_companion/ftpd', '/root/ftpd_root'], stdout=devnull, stderr=devnull)

MSG_QUEUE_LEN = 32
MAIN_CHECK_INTERVAL = 5


if __name__ == '__main__':
	gpio = onionGpio.OnionGpio(41)
	gpio.setOutputDirection(1)
	gpio.setValue(1)

	from optparse import OptionParser
	parser = OptionParser("main.py [options]")
	parser.add_option("-d", dest="debug", action="store_true", help="debug", default =False)
	(opts, args) = parser.parse_args()

	signal.signal(signal.SIGINT, quit)
	signal.signal(signal.SIGTERM, quit)

	companion_dir =		'/root/'	
	logfile =			companion_dir + 'companion.log'

	os.system("iw dev wlan0 set power_save off")
	os.system("uci delete wireless.default_radio1.bssid;uci commit;sleep 1;wifi")
	
	kill_ftpd()
	run_ftpd()

	if opts.debug:
		#logging.basicConfig(filename=logfile, filemode='w', format='%(levelname)s|%(asctime)s|%(message)s', level=logging.DEBUG)
		logging.basicConfig(format='%(levelname)s|%(asctime)s|%(message)s', level=logging.DEBUG)
		logging.debug('debug')
	else:
		rfh = logging.handlers.RotatingFileHandler(
			filename=logfile, 
			mode='a',
			maxBytes=256*1024,
			backupCount=1,
			encoding=None,
			delay=0
		)
		logging.basicConfig(filename=logfile, filemode='a', format='%(levelname)s|%(asctime)s|%(message)s', level=logging.INFO, handlers=[rfh])
	logging.info('main|init')

	proc = subprocess.Popen("uci get network.usbwan.netmask", stdout = subprocess.PIPE, shell= True)
	(out, err) = proc.communicate()
	netmask = out.split('.')
	logging.info("main|netmask:"+str(netmask[0])+"."+str(netmask[1])+ "."+str(netmask[2])+"."+str(netmask[3]))
	if(((int)(netmask[1])) != 240):
		os.system("uci set network.usbwan.netmask=255.240.0.0")
		os.system("uci commit")
		os.system("/ect/init.d/system reload")
		os.system("sleep 1;wifi")
	os.system("rm -f /etc/rc.button/reset")
	# check default ssid 
	if misc.is_default_ssid():
		logging.debug('default ssid, switch to saved ssid')
		misc.set_ssid(misc.get_saved_ssid())
		misc.rm_saved_ssid()

	queue_uav_to_companion = Queue.Queue(MSG_QUEUE_LEN)
	queue_gcs_to_companion = Queue.Queue(MSG_QUEUE_LEN)
	queue_companion_to_uav = Queue.Queue(MSG_QUEUE_LEN)
	queue_companion_to_gcs = Queue.Queue(MSG_QUEUE_LEN)	
	queue_update_type	 = Queue.Queue(MSG_QUEUE_LEN)
	# first start uav and wait for bootloader over, then start gcs and companion
	uav = 		uav.UAV(companion_dir, queue_uav_to_companion, queue_companion_to_uav)
	gcs = 		gcs.GCS(queue_gcs_to_companion, queue_companion_to_gcs, queue_update_type)
	companion =	companion.Companion(companion_dir, queue_uav_to_companion, queue_companion_to_uav, queue_gcs_to_companion, queue_companion_to_gcs,queue_update_type)

	while True:
		#print('main')
		time.sleep(MAIN_CHECK_INTERVAL)

		if not companion.thread_check.is_alive() or not companion.thread_uav_to_gcs.is_alive() or not companion.thread_gcs_to_uav.is_alive() or \
			not gcs.thread_udp_to_companion.is_alive() or not gcs.thread_companion_to_udp.is_alive() or \
			not uav.thread_uart_to_companion.is_alive() or not uav.thread_companion_to_uart.is_alive() :
			if not companion.thread_check.is_alive() :
				logging.error('main|thread_check dead')
			if not companion.thread_uav_to_gcs.is_alive():
				logging.error('main|thead_uav_to_gcs dead')
			if not companion.thread_gcs_to_uav.is_alive() :
				logging.error('main|thead_gcs_to_uav dead')
			if not gcs.thread_udp_to_companion.is_alive() :
				logging.error('main|thread_udp_to_companion dead')
			if not gcs.thread_companion_to_udp.is_alive():
				logging.error('main|thread_companion_to_udp dead')
			if not uav.thread_uart_to_companion.is_alive():
				logging.error('main|thread_uart_to_companion dead')
			if not uav.thread_companion_to_uart.is_alive():
				logging.error('main|thread_comnpanion_to_uart dead')
			
			
			logging.error('main|restart!!!')
			# restart 
			os.execl('/usr/bin/python', os.path.abspath(__file__), *sys.argv)
			


			